#include <stdio.h>
#include <functions.h>

int main(int argc, char **argv)
{	
	char* String = GetName();
	Print(String);
return 0;
}
#include <functions.h>
#include <stdlib.h>

char *GetName()
{
	printf("Enter a String: ");
	char *String=(char *)malloc(100*sizeof(char));
	scanf("%s", String);
return String;
}

void Print(char *s)
{
	printf("Hello %s\n", s);
}
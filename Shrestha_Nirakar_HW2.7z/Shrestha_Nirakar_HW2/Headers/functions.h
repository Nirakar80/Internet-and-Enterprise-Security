#include <stdio.h> 

char *GetName();
void Print(char *);
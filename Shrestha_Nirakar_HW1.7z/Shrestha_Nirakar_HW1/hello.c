#include <stdio.h> /* for printf() */

int main(int argc, char **argv)
{
 char *myString="Hello, world!";
 printf("%s\n", myString);
return 0;
}